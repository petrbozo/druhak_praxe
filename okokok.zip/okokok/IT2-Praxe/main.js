document.addEventListener("DOMContentLoaded", () => {
  const storedReports = JSON.parse(localStorage.getItem("reports")) || [];
  storedReports.forEach(report => {
    addReport(report.name, report.severity, report.date, report.description);
  });

  document.querySelector(".logout").addEventListener("click", () => {
    showLogoutConfirmation();
  });

  document.querySelector(".add").addEventListener("click", () => {
    const modal = document.getElementById("modal");
    const modalContent = document.getElementById("modal-content");
    const today = new Date().toISOString().split('T')[0];

    modalContent.innerHTML = `
      <div style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:400px; font-family:sans-serif;">
        <h2 style="margin-top:0;">New Report</h2>
        <div style="margin-bottom:15px;">
          <label>Name</label><br>
          <input type="text" id="name" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
        </div>
        <div style="margin-bottom:15px;">
          <label>Severity</label><br>
          <select id="severity" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
            <option value="Low">Low</option>
            <option value="Mid">Mid</option>
            <option value="High">High</option>
            <option value="Severe">Severe</option>
          </select>
        </div>
        <div style="margin-bottom:15px;">
          <label>Date</label><br>
          <input type="date" id="date" value="${today}" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
        </div>
        <div style="margin-bottom:20px;">
          <label>Description</label><br>
          <textarea id="description" rows="4" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;"></textarea>
        </div>
        <button id="submitReport" style="background:#28a745; color:white; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Add</button>
      </div>
    `;

    modal.style.display = "flex";

    document.getElementById("submitReport").addEventListener("click", () => {
      const name = document.getElementById("name").value;
      const severity = document.getElementById("severity").value;
      const date = document.getElementById("date").value;
      const description = document.getElementById("description").value;

      addReport(name, severity, date, description);
      saveReportsToLocalStorage();
      modal.style.display = "none";
    });
  });

  document.querySelector(".delete").addEventListener("click", () => {
    const checked = document.querySelectorAll(".report-check:checked");
    if (checked.length === 0) {
      alert("No reports selected.");
      return;
    }
    showDeleteConfirmation();
  });
});

function addReport(name, severity, date, description, isEdited = false) {
  const reportsList = document.querySelector(".reports-list");
  const today = new Date().toISOString().split("T")[0];
  const editedLabel = isEdited ? " (edited)" : "";

  const report = document.createElement("div");
  report.classList.add("report");
  report.style = `
    background:#fff;
    padding:20px;
    margin-top:30px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.1);
    max-width:600px;
    margin-left:auto;
    margin-right:auto;
    font-family:sans-serif;
    position:relative;
  `;

  report.innerHTML = `
    <div>
      <div style="display:flex; justify-content:space-between; align-items:flex-start;">
        <div>
          <strong>Name:</strong> <span class="r-name">${name}</span><br>
          <strong>Severity:</strong> <span class="r-severity">${severity}</span><br>
          <strong>Date:</strong> <span class="r-date">${isEdited ? today : date}</span>${editedLabel}
        </div>
        <button class="edit-btn" style="background:#007bff; color:white; border:none; padding:6px 10px; border-radius:6px; cursor:pointer; height: fit-content;">Edit</button>
      </div>
      <div style="margin-top:10px;">
        <strong>Description:</strong><br>
        <p class="r-desc" style="margin:5px 0 0;">${description}</p>
      </div>
      <div style="text-align:right; margin-top:10px;">
        <input type="checkbox" class="report-check"> Select
      </div>
    </div>
  `;

  reportsList.appendChild(report);

  report.querySelector(".edit-btn").addEventListener("click", () => {
    openEditModal(report);
  });
}

function openEditModal(reportElement) {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  const name = reportElement.querySelector(".r-name").textContent;
  const severity = reportElement.querySelector(".r-severity").textContent;
  const description = reportElement.querySelector(".r-desc").textContent;
  const today = new Date().toISOString().split('T')[0];

  modalContent.innerHTML = `
    <div style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:400px; font-family:sans-serif;">
      <h2>Edit Report</h2>
      <div style="margin-bottom:15px;">
        <label>Name</label><br>
        <input type="text" id="edit-name" value="${name}" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
      </div>
      <div style="margin-bottom:15px;">
        <label>Severity</label><br>
        <select id="edit-severity" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
          <option ${severity === "Low" ? "selected" : ""}>Low</option>
          <option ${severity === "Mid" ? "selected" : ""}>Mid</option>
          <option ${severity === "High" ? "selected" : ""}>High</option>
          <option ${severity === "Severe" ? "selected" : ""}>Severe</option>
        </select>
      </div>
      <div style="margin-bottom:20px;">
        <label>Description</label><br>
        <textarea id="edit-description" rows="4" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">${description}</textarea>
      </div>
      <button id="save-edit" style="background:#ffc107; color:white; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Save</button>
    </div>
  `;

  modal.style.display = "flex";

  document.getElementById("save-edit").addEventListener("click", () => {
    const newName = document.getElementById("edit-name").value;
    const newSeverity = document.getElementById("edit-severity").value;
    const newDescription = document.getElementById("edit-description").value;

    reportElement.remove();
    addReport(newName, newSeverity, today, newDescription, true);
    saveReportsToLocalStorage();
    modal.style.display = "none";
  });
}

function saveReportsToLocalStorage() {
  const allReports = Array.from(document.querySelectorAll(".report")).map(reportEl => ({
    name: reportEl.querySelector(".r-name").textContent,
    severity: reportEl.querySelector(".r-severity").textContent,
    date: reportEl.querySelector(".r-date").textContent.replace(" (edited)", ""),
    description: reportEl.querySelector(".r-desc").textContent
  }));
  localStorage.setItem("reports", JSON.stringify(allReports));
}

function showDeleteConfirmation() {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  modalContent.innerHTML = `
    <div style="background:#eee; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:300px; text-align:center; font-family:sans-serif;">
      <p style="margin-bottom:20px;">Are you sure you want to delete selected reports?</p>
      <div style="display:flex; justify-content:space-between;">
        <button id="cancelDelete" style="padding:10px 16px; background:#ccc; border:none; border-radius:6px; cursor:pointer;">cancel</button>
        <button id="confirmDelete" style="padding:10px 16px; background:#dc3545; color:white; border:none; border-radius:6px; cursor:pointer;">Delete</button>
      </div>
    </div>
  `;

  modal.style.display = "flex";

  document.getElementById("cancelDelete").addEventListener("click", () => {
    modal.style.display = "none";
  });

  document.getElementById("confirmDelete").addEventListener("click", () => {
    deleteSelectedReports();
    showDeleteSuccess();
  });
}

function deleteSelectedReports() {
  const selectedReports = document.querySelectorAll(".report-check:checked");
  selectedReports.forEach(checkbox => {
    const reportDiv = checkbox.closest(".report");
    if (reportDiv) reportDiv.remove();
  });
  saveReportsToLocalStorage();
}

function showDeleteSuccess() {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  modalContent.innerHTML = `
    <div style="background:#eee; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:300px; text-align:center; font-family:sans-serif;">
      <p style="margin-bottom:20px;">Sellected reports where deleted</p>
      <button id="okDeleted" style="padding:10px 16px; background:#28a745; color:white; border:none; border-radius:6px; cursor:pointer;">OK</button>
    </div>
  `;

  document.getElementById("okDeleted").addEventListener("click", () => {
    modal.style.display = "none";
  });
}

function showLogoutConfirmation() {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  modalContent.innerHTML = `
    <div style="background:#eee; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:300px; text-align:center; font-family:sans-serif;">
      <p style="margin-bottom:20px;">Are you sure you want to log out?</p>
      <div style="display:flex; justify-content:space-between;">
        <button id="cancelLogout" style="padding:10px 16px; background:#ccc; border:none; border-radius:6px; cursor:pointer;">cancel</button>
        <button id="confirmLogout" style="padding:10px 16px; background:#dc3545; color:white; border:none; border-radius:6px; cursor:pointer;">log out</button>
      </div>
    </div>
  `;

  modal.style.display = "flex";

  document.getElementById("cancelLogout").addEventListener("click", () => {
    modal.style.display = "none";
  });

  document.getElementById("confirmLogout").addEventListener("click", () => {
    localStorage.removeItem("user");
    showLogoutSuccess();
  });
}

function showLogoutSuccess() {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  modalContent.innerHTML = `
    <div style="background:#eee; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:300px; text-align:center; font-family:sans-serif;">
      <p style="margin-bottom:20px;">you were log out</p>
      <button id="okLogout" style="padding:10px 16px; background:#28a745; color:white; border:none; border-radius:6px; cursor:pointer;">OK</button>
    </div>
  `;

  document.getElementById("okLogout").addEventListener("click", () => {
    window.location.href = "index.html"; 
  });
}

document.addEventListener("DOMContentLoaded", () => {
  

  document.querySelector(".filter").addEventListener("click", () => {
    const modal = document.getElementById("modal");
    const modalContent = document.getElementById("modal-content");

    modalContent.innerHTML = `
      <div style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:400px; font-family:sans-serif;">
        <h2>Filter Reports</h2>
        <div style="margin-bottom:15px;">
          <label>Name</label><br>
          <input type="text" id="filter-name" style="width:100%; padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
          <label>Date</label><br>
          <input type="date" id="filter-date" style="width:100%; padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
          <label>Severity</label><br>
          <select id="filter-severity" style="width:100%; padding:8px;">
            <option value="">-- Any --</option>
            <option value="Low">Low</option>
            <option value="Mid">Mid</option>
            <option value="High">High</option>
            <option value="Severe">Severe</option>
          </select>
        </div>
        <button id="apply-filter" style="background:#007bff; color:white; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Apply Filter</button>
      </div>
    `;

    modal.style.display = "flex";

    document.getElementById("apply-filter").addEventListener("click", () => {
      const nameFilter = document.getElementById("filter-name").value.toLowerCase();
      const dateFilter = document.getElementById("filter-date").value;
      const severityFilter = document.getElementById("filter-severity").value;

      const allReports = JSON.parse(localStorage.getItem("reports")) || [];

      const filtered = allReports.filter(report => {
        const nameMatch = !nameFilter || report.name.toLowerCase().includes(nameFilter);
        const dateMatch = !dateFilter || report.date === dateFilter;
        const severityMatch = !severityFilter || report.severity === severityFilter;
        return nameMatch && dateMatch && severityMatch;
      });

      const reportsList = document.querySelector(".reports-list");
      reportsList.innerHTML = "";

      filtered.forEach(report => {
        addReport(report.name, report.severity, report.date, report.description);
      });

      modal.style.display = "none";
    });
  });
});
