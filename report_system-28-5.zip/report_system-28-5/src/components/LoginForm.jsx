function LoginForm() {
  return (
    <div className="container">
      <div className="login-box">
        <div className="form-left">
          <h2>Login form</h2>
          <label htmlFor="name">Name</label>
          <input type="text" id="name" name="name" placeholder="Enter your name" />
          <label htmlFor="password">Password</label>
          <input type="password" id="password" name="password" placeholder="Enter your password" />
        </div>
        <div className="form-right">
          <button onclick="login()">Log in</button>
        </div>
      </div>
    </div>
  );
}

export default LoginForm;
