document.querySelector(".add").addEventListener("click", () => {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  const today = new Date().toISOString().split('T')[0];

  modalContent.innerHTML = `
    <div style="
      background:#fff; 
      padding:30px; 
      border-radius:12px; 
      box-shadow:0 8px 20px rgba(0,0,0,0.2);
      width:400px;
      font-family:sans-serif;
    ">
      <h2 style="margin-top:0;">New Report</h2>

      <div style="margin-bottom:15px;">
        <label>Name</label><br>
        <input type="text" id="name" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
      </div>
 
      <div style="margin-bottom:15px;">
        <label>Severity</label><br>
        <select id="severity" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
          <option value="Low">Low</option>
          <option value="Mid">Mid</option>
          <option value="High">High</option>
          <option value="Severe">Severe</option>
        </select>
      </div>

      <div style="margin-bottom:15px;">
        <label>Date</label><br>
        <input type="date" id="date" value="${today}" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
      </div>

      <div style="margin-bottom:20px;">
        <label>Description</label><br>
        <textarea id="description" rows="4" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;"></textarea>
      </div>

      <button id="submitReport" style="
        background:#28a745; 
        color:white; 
        border:none; 
        padding:10px 16px; 
        border-radius:6px;
        cursor:pointer;
      ">Add</button>
    </div>
  `;

  modal.style.display = "flex";

  document.getElementById("submitReport").addEventListener("click", () => {
    const name = document.getElementById("name").value;
    const severity = document.getElementById("severity").value;
    const date = document.getElementById("date").value;
    const description = document.getElementById("description").value;

    addReport(name, severity, date, description);
    modal.style.display = "none";
  });
});

function addReport(name, severity, date, description, isEdited = false) {
  const reportsList = document.querySelector(".reports-list");
  const today = new Date().toISOString().split("T")[0];
  const editedLabel = isEdited ? " (edited)" : "";

  const report = document.createElement("div");
  report.style = `
    background:#fff;
    padding:20px;
    margin-top:30px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.1);
    max-width:600px;
    margin-left:auto;
    margin-right:auto;
    font-family:sans-serif;
    position:relative;
  `;

 report.innerHTML = `
  <div>
    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
      <div>
        <strong>Name:</strong> <span class="r-name">${name}</span><br>
        <strong>Severity:</strong> <span class="r-severity">${severity}</span><br>
        <strong>Date:</strong> <span class="r-date">${isEdited ? today : date}</span>${editedLabel}
      </div>
      <button class="edit-btn" style="
        background:#007bff; 
        color:white; 
        border:none; 
        padding:6px 10px; 
        border-radius:6px; 
        cursor:pointer;
        height: fit-content;
      ">Edit</button>
    </div>

    <div style="margin-top:10px;">
      <strong>Description:</strong><br>
      <p class="r-desc" style="margin:5px 0 0;">${description}</p>
    </div>

    <div style="text-align:right; margin-top:10px;">
      <input type="checkbox" class="report-check"> Select
    </div>
  </div>
`;


  reportsList.appendChild(report);

  report.querySelector(".edit-btn").addEventListener("click", () => {
    openEditModal(report);
  });
}

function openEditModal(reportElement) {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  const name = reportElement.querySelector(".r-name").textContent;
  const severity = reportElement.querySelector(".r-severity").textContent;
  const description = reportElement.querySelector(".r-desc").textContent;

  const today = new Date().toISOString().split('T')[0];

  modalContent.innerHTML = `
    <div style="
      background:#fff; 
      padding:30px; 
      border-radius:12px; 
      box-shadow:0 8px 20px rgba(0,0,0,0.2);
      width:400px;
      font-family:sans-serif;
    ">
      <h2>Edit Report</h2>

      <div style="margin-bottom:15px;">
        <label>Name</label><br>
        <input type="text" id="edit-name" value="${name}" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
      </div>

      <div style="margin-bottom:15px;">
        <label>Severity</label><br>
        <select id="edit-severity" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
          <option ${severity === "Low" ? "selected" : ""}>Low</option>
          <option ${severity === "Mid" ? "selected" : ""}>Mid</option>
          <option ${severity === "High" ? "selected" : ""}>High</option>
          <option ${severity === "Severe" ? "selected" : ""}>Severe</option>
        </select>
      </div>

      <div style="margin-bottom:20px;">
        <label>Description</label><br>
        <textarea id="edit-description" rows="4" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">${description}</textarea>
      </div>

      <button id="save-edit" style="
        background:#ffc107;
        color:white; 
        border:none; 
        padding:10px 16px; 
        border-radius:6px;
        cursor:pointer;
      ">Save</button>
    </div>
  `;

  modal.style.display = "flex";

  document.getElementById("save-edit").addEventListener("click", () => {
    const newName = document.getElementById("edit-name").value;
    const newSeverity = document.getElementById("edit-severity").value;
    const newDescription = document.getElementById("edit-description").value;

    reportElement.remove();
    addReport(newName, newSeverity, today, newDescription, true);

    modal.style.display = "none";
  });
}
