﻿namespace IT2_Reports_Backend
{
    public interface IDBAccess
    {
        Task<bool> IsUserExists(string username, string password = null);

        Task<List<Report>> GetAllReportsAsync();

        Task<bool> AddReportAsync(Report report);

        Task<bool> UpdateReportAsync(string name, Report report);

        Task<bool> DeleteReport(string name);
    }
}
