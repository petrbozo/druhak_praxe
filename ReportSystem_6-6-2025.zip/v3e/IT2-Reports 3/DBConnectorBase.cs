﻿using System.Data.SQLite;

namespace IT2_Reports_Backend
{
    public class DBConnectionBase : IDBConnectorBase
    {
        private readonly ILogger<DBConnectionBase> _logger;
        private SQLiteConnection sqlite_conn = null;

        private readonly string dataSource = "reports_sqlite.db";
        private readonly object _sync = new object();

        public DBConnectionBase(ILogger<DBConnectionBase> logger)
        {
            _logger = logger;
        }


        public SQLiteConnection GetConnection() => sqlite_conn;

        public SQLiteConnection Create()
        {
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection($"Data Source={dataSource}; Version = 3;");
            try
            {
                // Open the connection:
                sqlite_conn.Open();
            }
            catch (Exception )
            {
                //_logger.Error(ex, "Exception in CreateConnection");
            }
            return sqlite_conn;
        }

        public void Close()
        {
            sqlite_conn?.Close();
        }


        public delegate object ResultParser(SQLiteDataReader sqlite_datareader);

        public async Task<int> ExecuteNonQueryAsync(string sqlQuery)
        {
            if (Monitor.TryEnter(_sync, 1000))
            {
                try
                {
                    Create();

                    SQLiteCommand sqlite_cmd;
                    sqlite_cmd = sqlite_conn?.CreateCommand();
                    sqlite_cmd.CommandText = sqlQuery;
                    int result = await sqlite_cmd.ExecuteNonQueryAsync();

                    Close();

                    return result;
                }
                catch (Exception )
                {
                    //_logger.Error(ex, "Exception in SqlConnection::ExecuteNonQuery + CallStack " + ex.StackTrace);
                    return -2;
                }
                finally
                {
                    System.Threading.Monitor.Exit(_sync);
                }
            }
            else
            {
                //_logger.Error("Cannot enter in lock section!");
                return -2;

            }
        }

        public async Task<object> ReadDataAsync(string sqlQuery, ResultParser parser)
        {
            try
            {
                Create();

                SQLiteCommand sqlite_cmd;
                sqlite_cmd = GetConnection().CreateCommand();
                sqlite_cmd.CommandText = sqlQuery;

                SQLiteDataReader sqlite_datareader;
                sqlite_datareader = sqlite_cmd.ExecuteReader();

                var result = await Task.Run(() => parser.Invoke(sqlite_datareader));

                Close();

                return result;
            }
            catch (Exception )
            {
                //_logger.Error(ex, "Exception in SqlConnection::ReadDataAsync + stack " + ex.StackTrace);
                return null;
            }
        }
    }
}
