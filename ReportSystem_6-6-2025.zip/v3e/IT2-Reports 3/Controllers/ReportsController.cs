using Microsoft.AspNetCore.Mvc;

namespace IT2_Reports_Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController : ControllerBase
    {
        private readonly ILogger<ReportsController> _logger;
        private readonly IReportsService _service;

        public ReportsController(ILogger<ReportsController> logger, IReportsService service)
        {
            _logger = logger;
            _service = service;
        }


        [HttpPut]
        [Route("Login")]
        public async Task<IActionResult> Login(
            string username,
            string password)
        {
            bool response = await _service.Login(username, password);
            return response ? Ok() : BadRequest();
        }

        [HttpPut]
        [Route("Logout")]
        public async Task<IActionResult> Logout(
            string username)
        {
            bool response = await _service.Logout(username);
            return response ? Ok() : BadRequest();
        }


        [HttpPut]
        [Route("CreateReport")]
        public async Task<IActionResult> AddReport(
            [FromBody] Report newReport)
        {
            bool response = await _service.AddReportAsync(newReport);
            return response ? Ok() : BadRequest();
        }

        [HttpPut]
        [Route("UpdateReport")]
        public async Task<IActionResult> UpdateReport(
            string name,
            [FromBody] Report user)
        {
            bool response = await _service.UpdateReportAsync(name, user);
            return response ? Ok() : BadRequest();
        }

        [HttpDelete]
        [Route("DeleteReport")]
        public async Task<IActionResult> DeleteReport(
            string name)
        {
            bool response = await _service.DeleteReport(name);
            return response ? Ok() : BadRequest();
        }

        [HttpGet]
        [Route("GetAllReports")]
        public async Task<IActionResult> GetAllReports()
        {
            List<Report> reports = await _service.GetAllReportsAsync();
            return Ok(reports);
        }
    }
}
