﻿using System.Data.SQLite;

namespace IT2_Reports_Backend
{
    public class DBAccess : IDBAccess
    {
        private readonly ILogger<DBAccess> _logger;
        private readonly IDBConnectorBase _conn;

        public DBAccess(ILogger<DBAccess> logger, IDBConnectorBase conn)
        {
            _logger = logger;
            _conn = conn;
        }



        public async Task<bool> IsUserExists(string username, string password = null)
        {
            object ParserUserExists(SQLiteDataReader sqlite_datareader)
            {
                object res = sqlite_datareader.HasRows ? new object() : null;
                while (sqlite_datareader.Read()) { }
                return res;
            }

            string checkSql = $"SELECT username FROM Users WHERE username = '{username}' ";
            if ( password != null) checkSql += $" AND password = '{password}'; ";

            object result = (object) await _conn.ReadDataAsync(checkSql, ParserUserExists);
            return result != null;
        }

        public async Task<bool> IsReportExists(string name)
        {
            object ParserReportExists(SQLiteDataReader sqlite_datareader)
            {
                object res = sqlite_datareader.HasRows ? new object() : null;
                while (sqlite_datareader.Read()) { }
                return res;
            }

            string checkSql = $"SELECT id FROM Reports WHERE name = '{name}' ; ";

            object result = (object)await _conn.ReadDataAsync(checkSql, ParserReportExists);
            return result != null;
        }

        public async Task<bool> AddReportAsync(Report report)
        {
            if (await IsReportExists(report.Name))
                return false;

            string insertSql = $"INSERT INTO Reports ";
            insertSql += "('name', 'type', 'severity', 'timestamp', 'description') ";
            insertSql += "VALUES ";
            insertSql += $"( '{report.Name}', '{report.Type}', '{report.Severity}', '{report.Timestamp}', '{report.Description}' ) ; ";

            int res = await _conn.ExecuteNonQueryAsync(insertSql);

            return res == 1;
        }

        public async Task<bool> UpdateReportAsync(string name, Report report)
        {
            if (! await IsReportExists(name))
                return false;

            string updateSql = $"UPDATE Reports SET ";
            updateSql += $"name = '{report.Name}', ";
            updateSql += $"type = '{report.Type}', ";
            updateSql += $"severity = '{report.Severity}', ";
            updateSql += $"timestamp = '{report.Timestamp}', ";
            updateSql += $"description = '{report.Description}' ";
            updateSql += $"WHERE Reports.name = '{name}' ; ";

            int res = await _conn.ExecuteNonQueryAsync(updateSql);
 
            return res == 1;
        }

        public async Task<bool> DeleteReport(string name)
        {
            if (!await IsReportExists(name))
                return false;

            string deleteSql = $"DELETE FROM Reports WHERE name = '{name}' ; ";
            int res = await _conn.ExecuteNonQueryAsync(deleteSql);
            return res == 1;
        }

        public async Task<List<Report>> GetAllReportsAsync()
        {
            string checkSql = $"SELECT * FROM Reports ; ";
            List<Report> reports = (List<Report>)await _conn.ReadDataAsync(checkSql, GetAllReportsParser);
            return reports;
        }



        List<Report> GetAllReportsParser(SQLiteDataReader sqlite_datareader)
        {
            List<Report> result = new List<Report>();
            if (sqlite_datareader.HasRows)
            {
                while (sqlite_datareader.Read())
                {
                    Report report = new Report()
                    {
                        Id = sqlite_datareader.GetInt32(0),
                        Name = sqlite_datareader.GetString(1),
                        Type = sqlite_datareader.GetString(2),
                        Severity = sqlite_datareader.GetString(3),
                        Timestamp = sqlite_datareader.GetString(4),
                        Description = sqlite_datareader.IsDBNull(5) ? null : sqlite_datareader.GetString(5)
                    };

                    result.Add(report);
                }
            }
            return result;
        }
    }
}
