﻿using static IT2_Reports_Backend.DBConnectionBase;

namespace IT2_Reports_Backend
{
    public interface IDBConnectorBase
    {
        Task<int> ExecuteNonQueryAsync(string sqlQuery);
        Task<object> ReadDataAsync(string sqlQuery, ResultParser parser);
    }
}
