
namespace IT2_Reports_Backend
{
    public class ReportsService : IReportsService
    {
        private readonly ILogger<ReportsService> _logger;
        private readonly IDBAccess _connection;

        private string LoggedUsername = string.Empty;


        public ReportsService(
            ILogger<ReportsService> logger,
            IDBAccess connection)
        {
            _logger = logger;
            _connection = connection;
        }


        public async Task<bool> Login(string username, string password)
        {
            if (LoggedUsername != string.Empty) return false;

            bool result = await _connection.IsUserExists(username, password);

            if (result)
                LoggedUsername = username;
            return result;
        }

        public async Task<bool> Logout(string username)
        {
            if (LoggedUsername != username) return false;

            LoggedUsername = string.Empty;

            return true;
        }


        public async Task<bool> AddReportAsync(Report report)
        {
            if (LoggedUsername == string.Empty) return false;

            return await _connection.AddReportAsync(report);
        }

        public async Task<bool> UpdateReportAsync(string name, Report user)
        {
            if (LoggedUsername == string.Empty) return false;
            
            return await _connection.UpdateReportAsync(name, user);
        }

        public async Task<bool> DeleteReport(string name)
        {
            if (LoggedUsername == string.Empty) return false;

            return await _connection.DeleteReport(name);
        }

        public async Task<List<Report>> GetAllReportsAsync()
        {
            if (LoggedUsername == string.Empty) return new List<Report>();
            
            return await _connection.GetAllReportsAsync();
        }
    }
}
