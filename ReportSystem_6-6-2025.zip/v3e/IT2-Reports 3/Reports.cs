﻿namespace IT2_Reports_Backend
{
    public class Report
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Severity { get; set; }
        public string Timestamp { get; set; }
        public string Description { get; set; }
    }
}
