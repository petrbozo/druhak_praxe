﻿using System.Security.Policy;
using System.Xml.Linq;

namespace IT2_Reports_Backend
{
    public interface IReportsService
    {
        Task<bool> Login(string username, string password);

        Task<bool> Logout(string username);

        Task<bool> AddReportAsync(Report report);

        Task<bool> UpdateReportAsync(string name, Report user);

        Task<bool> DeleteReport(string name);

        Task<List<Report>> GetAllReportsAsync();
    }
}
