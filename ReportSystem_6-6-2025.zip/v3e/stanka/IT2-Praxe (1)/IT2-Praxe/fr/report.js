let reports_array = []

const report1 = new Report(
  1,
  user_id,
  "Chyba v systému přihlášení",
  "high",
  "2025-05-26T09:00:00Z",
  "2025-05-26T10:30:00Z",
  "Popis nahlášeného problému"
);

reports_array.push(report1)

const report3 = new Report(
  2,
  user_id,
  "Špatně načetlý design stránky",
  "mid",
  "2025-05-26T10:00:00Z",
  "2025-05-26T12:30:00Z",
  "Popis nahlášeného problému"
);

reports_array.push(report2)

const report2 = new Report(
  3,
  user_id,
  "Zapomenuté heslo",
  "critical",
  "2025-05-26T13:00:00Z",
  "2025-05-27T10:30:00Z",
  "Popis nahlášeného problému"
);

reports_array.push(report3)


// funkce delete

/* 
zavola se funkce delete_report pomoci tlacitka delete na strance
stánka vrátí array (i kdyby jen s jedním elementem) pro smazání
funkce iteruje pro každý element pro smazání
*/


function delete_report(report_ids) {
  for (let j = 0; j < report_ids; j++) {
    for (let i = 0; i < reports_array.length; i++) {
      if (report_id == reports_array[i].id) {
        reports_array.pop(i);
      }
    }
  }
}