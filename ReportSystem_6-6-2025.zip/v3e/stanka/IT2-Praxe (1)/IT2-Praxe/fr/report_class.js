class Report {
  constructor(id, reporter, name, severity, creation_date, edit_date, description) {
    this.id = id;
    this.reporter = reporter;
    this.name = name;
    this.severity = severity;
    this.creation_date = timestamp;
    this.edit_date = edit_date
    this.description = description;
  }
}