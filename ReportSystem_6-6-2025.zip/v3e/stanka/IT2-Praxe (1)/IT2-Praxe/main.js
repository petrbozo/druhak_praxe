

// CELEJ LOGIN

const nameInput = document.getElementById("login_name");
const passwordInput = document.getElementById("login_password");
let username;

// login

async function login() {
  username = nameInput.value.trim();
  localStorage.setItem("usernameKey", username)
  const password = passwordInput.value.trim();

  try {
    const response = await fetch(
      'https://localhost:7070/api/Reports/Login?username=' + encodeURIComponent(username) +
      '&password=' + encodeURIComponent(password),
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.ok) {
      console.log('✅ Přihlášení úspěšné (status:', response.status, ')');
      window.location.href = "main.html";
    } else {
      console.error('❌ Přihlášení selhalo (status:', response.status, ')');
    }
  } catch (error) {
    console.error('❌ Chyba při přihlášení:', error);
  }
}

// logout

async function logout() {
  username = localStorage.getItem("usernameKey")
  try {
    const response = await fetch(
      'https://localhost:7070/api/Reports/Logout?username=' + encodeURIComponent(username),
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.ok) {
      console.log('✅ Odhlášení úspěšné (status:', response.status, ')');
      window.location.href = "login.html";
    } else {
      console.error('❌ Odhlášení selhalo (status:', response.status, ')');
    }
  } catch (error) {
    console.error('❌ Chyba při Odhlášení:', error);
  }
}


//CELEJ MAIN


class Report {
  constructor(id, name, type, severity, timestamp, description) {
    this.id = id;
    this.name = name;
    this.type = type;
    this.severity = severity;
    this.timestamp = timestamp;
    this.description = description;
  }
}

function convertToTimestamp(dateString) {
  return new Date(dateString + "T00:00:00").toISOString();
}

document.addEventListener("DOMContentLoaded", async () => {
  const storedReports = await getAllReports();
  storedReports.forEach(data => {
    const report = new Report(data.id, data.name, data.type, data.severity, data.date, data.description);
    addReport(report);
  });
});

async function getAllReports() {
  try {
    const response = await fetch(
      'https://localhost:7070/api/Reports/GetAllReports',
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.ok) {
      const reports = await response.json();
      console.log('✅ Reports fetched successfully:', reports);
      return reports;
    } else {
      console.error('❌ Failed to fetch reports (status:', response.status, ')');
      return [];
    }
  } catch (error) {
    console.error('❌ Error while fetching reports:', error);
    return [];
  }
}

async function updateReport(report) {
  const { id, name, type, severity, timestamp, description } = report;

  try {
    const response = await fetch(
      'https://localhost:7070/api/Reports/UpdateReport?name=' + encodeURIComponent(name),
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id,
          name,
          type,
          severity,
          timestamp,
          description
        })
      }
    );

    if (response.ok) {
      const updatedReport = await response.json();
      console.log('✅ Report updated successfully:', updatedReport);
      return updatedReport;
    } else {
      console.error('❌ Failed to update report (status:', response.status, ')');
      return null;
    }
  } catch (error) {
    console.error('❌ Error during report update:', error);
    return null;
  }
}

// add report

function add() {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");
  const today = new Date().toISOString().split('T')[0];

  modalContent.innerHTML = `
      <div style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:400px; font-family:sans-serif;">
        <h2 style="margin-top:0;">New Report</h2>
        <div style="margin-bottom:15px;">
          <label>Name</label><br>
          <input type="text" id="name" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
        </div>
        <div style="margin-bottom:15px;">
          <label>Severity</label><br>
          <select id="severity" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
            <option value="Low">Low</option>
            <option value="Mid">Mid</option>
            <option value="High">High</option>
            <option value="Severe">Severe</option>
          </select>
        </div>
        <div style="margin-bottom:15px;">
          <label>Date</label><br>
          <input type="date" id="date" value="${today}" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
        </div>
        <div style="margin-bottom:20px;">
          <label>Description</label><br>
          <textarea id="description" rows="4" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;"></textarea>
        </div>
        <button id="submitReport" style="background:#28a745; color:white; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Add</button>
      </div>
    `;

  modal.style.display = "flex";

  document.getElementById("submitReport").addEventListener("click", async () => {
    id = 0;
    const name = document.getElementById("name").value;
    const type = "report";
    const severity = document.getElementById("severity").value;
    const date = document.getElementById("date").value;
    const description = document.getElementById("description").value;

    const timestamp = String(convertToTimestamp(date));

    const report = new Report(id, name, type, severity, timestamp, description);
    addReport(report);

    await createReport({
      id,
      name,
      type,
      severity,
      timestamp,
      description
    });

    modal.style.display = "none";
  });
}

function addReport(reportObj, isEdited = false) {
  const { name, severity, date, description } = reportObj;
  const reportsList = document.querySelector(".reports-list");
  const today = new Date().toISOString().split("T")[0];
  const editedLabel = isEdited ? " (edited)" : "";

  const report = document.createElement("div");
  report.classList.add("report");
  report.style = `
    background:#fff;
    padding:20px;
    margin-top:30px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.1);
    max-width:600px;
    margin-left:auto;
    margin-right:auto;
    font-family:sans-serif;
    position:relative;
  `;

  report.innerHTML = `
    <div>
      <div style="display:flex; justify-content:space-between; align-items:flex-start;">
        <div>
          <strong>Name:</strong> <span class="r-name">${name}</span><br>
          <strong>Severity:</strong> <span class="r-severity">${severity}</span><br>
          <strong>Date:</strong> <span class="r-date">${isEdited ? today : date}</span>${editedLabel}
        </div>
        <button class="edit-btn" style="background:#007bff; color:white; border:none; padding:6px 10px; border-radius:6px; cursor:pointer; height: fit-content;">Edit</button>
      </div>
      <div style="margin-top:10px;">
        <strong>Description:</strong><br>
        <p class="r-desc" style="margin:5px 0 0;">${description}</p>
      </div>
      <div style="text-align:right; margin-top:10px;">
        <button class="deleteButton" onclick="deleteReport('${name.replace(/'/g, "\\'")}')">Delete</button>
        <input type="checkbox" class="report-check"> Select
      </div>
    </div>
  `;

  reportsList.appendChild(report);

  report.querySelector(".edit-btn").addEventListener("click", () => {
    openEditModal(report);
  });
}

function openEditModal(reportElement) {
  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modal-content");

  const name = reportElement.querySelector(".r-name").textContent;
  const severity = reportElement.querySelector(".r-severity").textContent;
  const description = reportElement.querySelector(".r-desc").textContent;
  const today = new Date().toISOString().split('T')[0];

  modalContent.innerHTML = `
    <div style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:400px; font-family:sans-serif;">
      <h2>Edit Report</h2>
      <div style="margin-bottom:15px;">
        <label>Name</label><br>
        <input type="text" id="edit-name" value="${name}" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
      </div>
      <div style="margin-bottom:15px;">
        <label>Severity</label><br>
        <select id="edit-severity" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">
          <option ${severity === "Low" ? "selected" : ""}>Low</option>
          <option ${severity === "Mid" ? "selected" : ""}>Mid</option>
          <option ${severity === "High" ? "selected" : ""}>High</option>
          <option ${severity === "Severe" ? "selected" : ""}>Severe</option>
        </select>
      </div>
      <div style="margin-bottom:20px;">
        <label>Description</label><br>
        <textarea id="edit-description" rows="4" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:6px;">${description}</textarea>
      </div>
      <button id="save-edit" onclick="TADY SAVE EDIT FUNKCE" style="background:#ffc107; color:white; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Save</button>
    </div>
  `;

  modal.style.display = "flex";


  async function saveEdit(reportElement) {
    const newId = reportElement.id;
    const newName = document.getElementById("edit-name").value;
    const newSeverity = document.getElementById("edit-severity").value;
    const newDescription = document.getElementById("edit-description").value;
    const today = new Date().toISOString().split("T")[0];
    const timestamp = convertToTimestamp(today);

    reportElement.remove();
    const newReport = new Report(newId, newName, "report", newSeverity, timestamp, newDescription);
    addReport(newReport, true);


    await updateReport({
      id: id,
      name: newName,
      type: "report",
      severity: newSeverity,
      date: timestamp,
      description: newDescription
    });

    modal.style.display = "none";
  }
}

// vytvareni reportu

async function createReport(report) {
  try {
    const response = await fetch(
      'https://localhost:7070/api/Reports/CreateReport',
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(report)
      }
    );

    if (response.ok) {
      console.log('✅ CreateReport úspěšné (status:', response.status, ')');
    } else {
      console.error('❌ CreateReport selhalo (status:', response.status, ')');
    }
  } catch (error) {
    console.error('❌ Chyba při CreateReport:', error);
  }
}

//DELETE

async function deleteReport(name) {
  try {
    const response = await fetch(
      'https://localhost:7070/api/Reports/DeleteReport?name=' + name,
      {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        },
      }
    );

    if (response.ok) {
      console.log('✅ Delete úspěšné (status:', response.status, ')');
    } else {
      console.error('❌ Delete selhalo (status:', response.status, ')');
    }
  } catch (error) {
    console.error('❌ Chyba při Delete:', error);
  }
}

// SORT

document.addEventListener("DOMContentLoaded", () => {


  document.querySelector(".filter").addEventListener("click", () => {
    const modal = document.getElementById("modal");
    const modalContent = document.getElementById("modal-content");

    modalContent.innerHTML = `
      <div style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.2); width:400px; font-family:sans-serif;">
        <h2>Sort Reports</h2>
        <div style="margin-bottom:15px;">
          <label>Sort by</label><br>
          <select id="sort-option" style="width:100%; padding:8px;">
            <option value="name">Name</option>
            <option value="date">Date</option>
            <option value="severity">Severity</option>
          </select>
        </div>
        <div style="display:flex; justify-content:space-between;">
          <button id="cancel-sort" style="background:#ccc; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Cancel</button>
          <button id="apply-sort" style="background:#007bff; color:white; border:none; padding:10px 16px; border-radius:6px; cursor:pointer;">Sort</button>
        </div>
      </div>
    `;

    modal.style.display = "flex";

    document.getElementById("cancel-sort").addEventListener("click", () => {
      modal.style.display = "none";
    });

    document.getElementById("apply-sort").addEventListener("click", () => {
      const sortOption = document.getElementById("sort-option").value;
      //const allReports = JSON.parse(localStorage.getItem("reports")) || [];


      allReports.sort((a, b) => {
        if (sortOption === "name") {
          return a.name.localeCompare(b.name);
        } else if (sortOption === "date") {
          return new Date(a.date) - new Date(b.date);
        } else if (sortOption === "severity") {
          const levels = { "Low": 1, "Mid": 2, "High": 3, "Severe": 4 };
          return levels[a.severity] - levels[b.severity];
        }
      });

      const reportsList = document.querySelector(".reports-list");
      reportsList.innerHTML = "";

      allReports.forEach(report => {
        addReport(report.name, report.severity, report.date, report.description);
      });

      modal.style.display = "none";
    });
  });
});


// PDF


document.addEventListener("DOMContentLoaded", () => {


  document.querySelector(".pdf").addEventListener("click", () => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const selectedReports = Array.from(document.querySelectorAll(".report-check:checked"));
    if (selectedReports.length === 0) {
      alert("No reports selected for PDF.");
      return;
    }

    let yPosition = 10;
    selectedReports.forEach((checkbox, index) => {
      const reportDiv = checkbox.closest(".report");
      if (!reportDiv) return;

      const name = reportDiv.querySelector(".r-name").textContent;
      const severity = reportDiv.querySelector(".r-severity").textContent;
      const date = reportDiv.querySelector(".r-date").textContent;
      const description = reportDiv.querySelector(".r-desc").textContent;

      doc.setFontSize(14);
      doc.text(`Report ${index + 1}`, 10, yPosition);
      yPosition += 8;

      doc.setFontSize(12);
      doc.text(`Name: ${name}`, 10, yPosition);
      yPosition += 7;
      doc.text(`Severity: ${severity}`, 10, yPosition);
      yPosition += 7;
      doc.text(`Date: ${date}`, 10, yPosition);
      yPosition += 7;


      const splitDesc = doc.splitTextToSize(`Description: ${description}`, 180);
      doc.text(splitDesc, 10, yPosition);
      yPosition += splitDesc.length * 7 + 10;


      if (yPosition > 270) {
        doc.addPage();
        yPosition = 10;
      }
    });

    doc.save("reports.pdf");
  });
});

